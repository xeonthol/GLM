#!/usr/bin/env python3
"""
gleam_api.py — Gleam API client (no browser needed for tasks)
"""
import requests, json, time, re
from config import *


class GleamAPI:
    BASE = "https://gleam.io"

    def __init__(self, account: dict, logger):
        self.acc    = account
        self.logger = logger
        gleam       = account.get("gleam", {})
        self.csrf   = gleam.get("csrf", "")
        self.session= gleam.get("session", "")
        self.s      = requests.Session()
        self.s.headers.update({
            "User-Agent"      : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept"          : "application/json, text/javascript, */*; q=0.01",
            "Accept-Language" : "en-US,en;q=0.9",
            "Referer"         : GLEAM_URL,
            "Origin"          : "https://gleam.io",
            "X-CSRF-Token"    : self.csrf,
            "X-Requested-With": "XMLHttpRequest",
        })
        self.s.cookies.set("_gleam_session", self.session, domain="gleam.io")

    # ── CAMPAIGN ─────────────────────────────────────────────
    def get_campaign(self, key: str) -> dict:
        """Ambil detail campaign + entry methods"""
        r = self.s.get(f"{self.BASE}/{key}.json", timeout=15)
        r.raise_for_status()
        return r.json()

    def get_contestant(self, campaign_key: str) -> dict:
        """Ambil contestant ID (perlu buat claim entry)"""
        r = self.s.get(f"{self.BASE}/{campaign_key}/contestants/me.json", timeout=15)
        r.raise_for_status()
        return r.json()

    # ── ENTRY ─────────────────────────────────────────────────
    def enter_campaign(self, campaign_key: str) -> dict:
        """Register sebagai contestant"""
        r = self.s.post(
            f"{self.BASE}/contestants",
            json={"campaign_key": campaign_key},
            timeout=15
        )
        self.logger.info(f"  Enter campaign: {r.status_code}")
        return r.json() if r.ok else {}

    def claim_entry(self, contestant_id: int, entry_method_id: int, details: dict = None) -> dict:
        """Claim entry untuk 1 task"""
        payload = {
            "contestant_id"  : contestant_id,
            "entry_method_id": entry_method_id,
        }
        if details:
            payload["details"] = details

        r = self.s.post(
            f"{self.BASE}/entries",
            json=payload,
            timeout=15
        )
        self.logger.info(f"  Claim entry {entry_method_id}: {r.status_code} — {r.text[:100]}")
        return r.json() if r.ok else {"error": r.text}

    def verify_follow(self, contestant_id: int, entry_method_id: int) -> dict:
        """Verify Twitter follow task"""
        r = self.s.patch(
            f"{self.BASE}/entries/{entry_method_id}",
            json={
                "contestant_id"  : contestant_id,
                "entry_method_id": entry_method_id,
                "action"         : "verify",
            },
            timeout=15
        )
        self.logger.info(f"  Verify follow {entry_method_id}: {r.status_code} — {r.text[:100]}")
        return r.json() if r.ok else {"error": r.text}

    def submit_entry(self, contestant_id: int, entry_method_id: int, value: str) -> dict:
        """Submit task dengan value (repost URL, UID, dll)"""
        r = self.s.post(
            f"{self.BASE}/entries",
            json={
                "contestant_id"  : contestant_id,
                "entry_method_id": entry_method_id,
                "details"        : {"value": value},
            },
            timeout=15
        )
        self.logger.info(f"  Submit {entry_method_id}: {r.status_code} — {r.text[:100]}")
        return r.json() if r.ok else {"error": r.text}
