#!/usr/bin/env python3
"""
run.py — Gleam Bot (API-based, no browser for tasks)
Usage: python run.py <account_id>
"""
import sys, os, time, re
from helpers     import get_logger, load_account, pick_handles, mark_handles_used
from gleam_api   import GleamAPI
from twitter_api import TwitterAPI
from config      import *

os.makedirs(SCREENSHOT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)


def extract_campaign_key(url: str) -> str:
    m = re.search(r"gleam\.io/([^/]+)/", url)
    return m.group(1) if m else ""


def main():
    if len(sys.argv) < 2:
        print("Usage: python run.py <account_id>")
        sys.exit(1)

    account_id = int(sys.argv[1])
    logger     = get_logger(account_id)
    logger.info(f"🚀 Gleam Bot (API mode) — ACC#{account_id}")
    logger.info(f"   URL: {GLEAM_URL}")

    acc = load_account(account_id)
    logger.info(f"   Handle : @{acc.get('handle','?')}")
    logger.info(f"   UID    : {acc.get('kucoin_uid','?')}")

    # Validasi gleam credentials
    gleam_creds = acc.get("gleam", {})
    if not gleam_creds.get("csrf") or not gleam_creds.get("session"):
        logger.error("❌ gleam.csrf / gleam.session belum diisi di accounts.json!")
        logger.error("   Buka gleam.io → F12 → Network → lihat x-csrf-token & _gleam_session")
        sys.exit(1)

    gleam   = GleamAPI(acc, logger)
    twitter = TwitterAPI(acc, logger)

    # ── STEP 1: Get campaign info ─────────────────────────────
    campaign_key = extract_campaign_key(GLEAM_URL)
    logger.info(f"\n{'='*50}")
    logger.info(f"📋 Campaign key: {campaign_key}")

    try:
        campaign = gleam.get_campaign(campaign_key)
    except Exception as e:
        logger.error(f"❌ Gagal load campaign: {e}")
        sys.exit(1)

    comp   = campaign.get("campaign", campaign)
    name   = comp.get("name", "?")
    logger.info(f"   Name: {name}")

    # List entry methods
    methods = comp.get("entry_methods", [])
    logger.info(f"   Entry methods ({len(methods)}):")
    for m in methods:
        logger.info(f"     [{m['id']}] {m.get('entry_type','?')} — {m.get('mandatory',False)} — {m.get('name','')[:40]}")

    # ── STEP 2: Enter campaign (register contestant) ──────────
    logger.info(f"\n{'='*50}")
    logger.info("🎯 Enter campaign...")
    try:
        contestant_data = gleam.enter_campaign(campaign_key)
        contestant_id   = contestant_data.get("id") or contestant_data.get("contestant", {}).get("id")
        if not contestant_id:
            # Coba get existing contestant
            me = gleam.get_contestant(campaign_key)
            contestant_id = me.get("id")
        logger.info(f"   Contestant ID: {contestant_id}")
    except Exception as e:
        logger.error(f"❌ Enter campaign error: {e}")
        sys.exit(1)

    if not contestant_id:
        logger.error("❌ Contestant ID tidak ditemukan!")
        sys.exit(1)

    time.sleep(2)

    # ── STEP 3: Process each entry method ─────────────────────
    results = []
    tweet_url = ""

    for method in methods:
        mid   = method["id"]
        mtype = method.get("entry_type", "")
        mname = method.get("name", "")[:50]

        logger.info(f"\n{'='*50}")
        logger.info(f"⚙️  Task [{mid}] {mtype} — {mname}")
        time.sleep(2)

        # ── Twitter Follow ────────────────────────────────────
        if mtype in ("twitter_follow", "TweetFollow"):
            username = method.get("config", {}).get("screen_name", "")
            if not username:
                # Coba ambil dari name
                m2 = re.search(r"@(\w+)", mname)
                username = m2.group(1) if m2 else ""

            logger.info(f"   🐦 Follow @{username}...")
            ok = twitter.follow(username)
            time.sleep(3)

            if ok:
                result = gleam.claim_entry(contestant_id, mid)
                results.append({"task": mname, "ok": "error" not in result})
            else:
                results.append({"task": mname, "ok": False})

        # ── Twitter Retweet / Quote ───────────────────────────
        elif mtype in ("twitter_retweet", "TweetRetweet", "tweet_retweet"):
            logger.info(f"   💬 Quote tweet...")
            handles    = pick_handles(3)
            tags       = " ".join(f"@{h}" for h in handles)
            tweet_text = f"{TWEET_TEMPLATE.format(tag1=f'@{handles[0]}', tag2=f'@{handles[1]}', tag3=f'@{handles[2]}')}"

            tweet_url = twitter.quote_tweet(QUOTE_TWEET_URL, tweet_text)
            mark_handles_used(handles)
            time.sleep(3)

            if tweet_url:
                result = gleam.claim_entry(contestant_id, mid, {"value": tweet_url})
                results.append({"task": mname, "ok": "error" not in result})
            else:
                results.append({"task": mname, "ok": False})

        # ── Submit URL / Text ─────────────────────────────────
        elif mtype in ("twitter_retweet_url", "custom_action", "TweetUrl"):
            value = tweet_url or "?"
            logger.info(f"   📎 Submit URL: {value[:60]}")
            result = gleam.submit_entry(contestant_id, mid, value)
            results.append({"task": mname, "ok": "error" not in result})

        # ── Submit UID ────────────────────────────────────────
        elif "uid" in mname.lower() or "custom" in mtype.lower():
            uid = acc.get("kucoin_uid", "")
            logger.info(f"   🔑 Submit UID: {uid}")
            result = gleam.submit_entry(contestant_id, mid, str(uid))
            results.append({"task": mname, "ok": "error" not in result})

        else:
            logger.info(f"   ⏭️  Skip (unknown type: {mtype})")

    # ── SUMMARY ───────────────────────────────────────────────
    logger.info(f"\n{'='*50}")
    logger.info(f"📊 SUMMARY ACC#{account_id} @{acc.get('handle','?')}")
    for r in results:
        logger.info(f"   {'✅' if r['ok'] else '❌'} {r['task'][:50]}")
    logger.info("🎉 SELESAI!")


if __name__ == "__main__":
    main()
