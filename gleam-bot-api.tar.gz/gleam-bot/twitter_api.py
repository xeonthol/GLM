#!/usr/bin/env python3
"""
twitter_api.py — Twitter/X API client untuk follow & tweet
"""
import requests, json, time, re
from config import *


class TwitterAPI:
    BASE = "https://api.twitter.com/1.1"
    BASE2= "https://twitter.com/i/api/1.1"

    def __init__(self, account: dict, logger):
        self.acc    = account
        self.logger = logger
        cookies     = account.get("cookies", {})
        self.auth_token = cookies.get("auth_token", "")
        self.ct0        = cookies.get("ct0", "")
        self.s          = requests.Session()
        self.s.headers.update({
            "User-Agent"      : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept"          : "*/*",
            "Accept-Language" : "en-US,en;q=0.9",
            "Authorization"   : "Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA",
            "X-Csrf-Token"    : self.ct0,
            "X-Twitter-Auth-Type"        : "OAuth2Session",
            "X-Twitter-Active-User"      : "yes",
            "X-Twitter-Client-Language"  : "en",
        })
        self.s.cookies.set("auth_token", self.auth_token, domain=".twitter.com")
        self.s.cookies.set("ct0",        self.ct0,        domain=".twitter.com")
        self.s.cookies.set("auth_token", self.auth_token, domain=".x.com")
        self.s.cookies.set("ct0",        self.ct0,        domain=".x.com")

    def follow(self, username: str) -> bool:
        """Follow akun Twitter"""
        # Resolve user_id dulu
        user_id = self._get_user_id(username)
        if not user_id:
            self.logger.error(f"  Gagal resolve user_id @{username}")
            return False

        r = self.s.post(
            "https://twitter.com/i/api/1.1/friendships/create.json",
            data={
                "user_id"               : user_id,
                "skip_status"           : True,
                "include_blocklist_on_ids": True,
            },
            timeout=15
        )
        ok = r.status_code == 200
        self.logger.info(f"  Follow @{username} ({user_id}): {r.status_code} {'✅' if ok else '❌'}")
        if not ok:
            self.logger.debug(f"  Response: {r.text[:200]}")
        return ok

    def _get_user_id(self, username: str) -> str:
        """Resolve username → user_id"""
        r = self.s.get(
            "https://twitter.com/i/api/1.1/users/show.json",
            params={"screen_name": username},
            timeout=15
        )
        if r.ok:
            return str(r.json().get("id_str", ""))
        self.logger.debug(f"  users/show error: {r.status_code} {r.text[:100]}")
        return ""

    def quote_tweet(self, quote_url: str, text: str) -> str:
        """Post quote tweet, return URL tweet baru"""
        # Extract tweet ID dari URL
        m = re.search(r"/status/(\d+)", quote_url)
        if not m:
            self.logger.error(f"  Invalid quote URL: {quote_url}")
            return ""
        tweet_id = m.group(1)

        # Graphql create tweet
        r = self.s.post(
            "https://twitter.com/i/api/graphql/SoVnbfCycZ7fERGCwpZkYA/CreateTweet",
            json={
                "variables": {
                    "tweet_text"                    : text,
                    "attachment_url"                : quote_url,
                    "quote_tweet_id"                : tweet_id,
                    "dark_request"                  : False,
                    "media"                         : {"media_entities": [], "possibly_sensitive": False},
                    "semantic_annotation_ids"       : [],
                },
                "features": {
                    "tweetypie_unmention_optimization_enabled"              : True,
                    "responsive_web_edit_tweet_api_enabled"                 : True,
                    "graphql_is_translatable_rweb_tweet_is_translatable_enabled": True,
                    "view_counts_everywhere_api_enabled"                    : True,
                    "longform_notetweets_consumption_enabled"               : True,
                    "responsive_web_twitter_article_tweet_consumption_enabled": False,
                    "tweet_awards_web_tipping_enabled"                      : False,
                    "freedom_of_speech_not_reach_fetch_enabled"             : True,
                    "standardized_nudges_misinfo"                           : True,
                    "tweet_with_visibility_results_prefer_gql_limited_actions_policy_enabled": True,
                    "longform_notetweets_rich_text_read_enabled"            : True,
                    "longform_notetweets_inline_media_enabled"              : True,
                    "responsive_web_graphql_exclude_directive_enabled"      : True,
                    "verified_phone_label_enabled"                          : False,
                    "freedom_of_speech_not_reach_fetch_enabled"             : True,
                    "standardized_nudges_misinfo"                           : True,
                    "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
                    "responsive_web_graphql_timeline_navigation_enabled"    : True,
                    "responsive_web_enhance_cards_enabled"                  : False,
                },
                "queryId": "SoVnbfCycZ7fERGCwpZkYA",
            },
            timeout=15
        )

        if not r.ok:
            self.logger.error(f"  CreateTweet failed: {r.status_code} {r.text[:200]}")
            return ""

        data = r.json()
        try:
            tweet = data["data"]["create_tweet"]["tweet_results"]["result"]
            new_id = tweet["rest_id"]
            handle = tweet["core"]["user_results"]["result"]["legacy"]["screen_name"]
            url    = f"https://x.com/{handle}/status/{new_id}"
            self.logger.info(f"  ✅ Quote tweet: {url}")
            return url
        except Exception as e:
            self.logger.error(f"  Parse tweet response error: {e} — {str(data)[:200]}")
            return ""
